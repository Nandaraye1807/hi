from django.contrib import admin
from .models import Employee,Contract
# Register your models here.

class EmployeeAdmin (admin.ModelAdmin):
    list_display = ['name', 'address', 'age', 'email', 'birthday', 'image']

admin.site.register(Employee, EmployeeAdmin)

class ContractAdmin (admin.ModelAdmin):
    list_display = ['name', 'start_date', 'end_date', 'salary', 'position']

admin.site.register(Contract, ContractAdmin)

