from django.apps import AppConfig


class TemplateAppConfig(AppConfig):
    name = 'template_app'
