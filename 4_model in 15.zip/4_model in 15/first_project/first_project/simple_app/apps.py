from django.apps import AppConfig


class SimpleAppConfig(AppConfig):
    name = 'simple_app'
